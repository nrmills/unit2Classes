
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;

/**
 * This component draws the cityscape
 */
public class CityscapeComponent extends JComponent
{
    public void paintComponent(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        Building b1 = new Building(0,this.getHeight(),600,400,7,6);
        UFO u1 = new UFO(this.getWidth(),this.getHeight(),150,75);
        Moon m1 = new Moon(this.getWidth(), this.getHeight(),150,150,200,200,false);
        Landscape l1 = new Landscape(0,this.getHeight(),this.getWidth(),this.getHeight());
        Sky s1 = new Sky(this.getWidth(),this.getHeight());
        s1.draw(g2);
        l1.draw(g2);
        b1.draw(g2);
        u1.draw(g2);
        m1.draw(g2);
    }
}